OMNI CANVAS EMAIL — OPTION 02 "GAZETTE"
=======================================

FILES
  gazette-no-image.html    Type-only version. Zero images — renders complete
                          in Outlook with nothing to block/download.
  gazette-with-image.html  Same email with the brand graphic between headline and body.
  brand-crop.png          The graphic (1200x1200). A crop from the Omnicom
                          2025 Brand Guidelines — no bespoke art required.

HOW TO VIEW
  Open either .html in a browser.

NOTE ON THE IMAGE VERSION
  The <img> points at a hosted URL:
  https://lease-campaign.vercel.app/brand-crop-b.png
  Email clients cannot use local file paths, and embedded/attached images
  (CID, data URIs) are unreliable in Outlook. Production sends should host
  this file on an Omnicom domain and swap the URL.

BUILD NOTES
  - 600px table-based layout, all styles inline, MSO conditionals.
  - No webfonts. Sans: Helvetica Neue > Helvetica > Arial.
    Mono: Fira Code > Courier New (Fira Code is NOT email-safe; it is
    listed first as a nicety and falls back to Courier New everywhere).
  - Bulletproof CTA (bgcolor table cell, not a CSS-only button).
  - The OMNI wordmark is typeset text, not an image, so it always renders.
  - Hairlines: #dddfe1. Brand blue: #1858ee.
  - Merge fields in the headline: {{first_name}}, {{canvas_title}}.
  - All links currently point to a placeholder URL — replace before sending.
